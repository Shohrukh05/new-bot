import logging
from datetime import datetime

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(f'bot_{datetime.now().strftime("%Y%m%d")}.log'),
        logging.StreamHandler()
    ]
)

logger = logging.getLogger(__name__)

def log_error(error, context=None):
    """Log errors with additional context"""
    error_message = f"Error: {str(error)}"
    if context:
        error_message += f" | Context: {context}"
    logger.error(error_message)

def log_info(message):
    """Log information messages"""
    logger.info(message)
