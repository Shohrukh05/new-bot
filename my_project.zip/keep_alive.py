from flask import Flask, jsonify
from threading import Thread
import logging
from datetime import datetime
import time

# Configure Flask app
app = Flask(__name__)
app.logger.setLevel(logging.INFO)

# Track server start time
START_TIME = datetime.now()

@app.route('/')
def home():
    """Basic endpoint to verify server is running"""
    return "Bot is alive and running!"

@app.route('/health')
def health():
    """Health check endpoint with uptime information"""
    uptime = datetime.now() - START_TIME
    return jsonify({
        'status': 'healthy',
        'uptime': str(uptime),
        'start_time': START_TIME.isoformat()
    })

def run():
    """Run the Flask application"""
    try:
        app.run(host='0.0.0.0', port=8080)
    except Exception as e:
        app.logger.error(f"Error in keep-alive server: {e}")
        raise  # Re-raise to ensure the error is properly logged

def keep_alive():
    """Start the Flask server in a separate thread"""
    server_thread = Thread(target=run, daemon=True)
    server_thread.start()

    # Wait for the server to start
    time.sleep(2)  # Give the server time to initialize

    app.logger.info("Keep-alive server started successfully")
    return server_thread