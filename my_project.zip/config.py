import os
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# Bot Configuration
BOT_TOKEN = os.getenv("BOT_TOKEN")
PUBLIC_CHANNEL_USERNAME = os.getenv("PUBLIC_CHANNEL_USERNAME")
PRIVATE_GROUP_ID = os.getenv("PRIVATE_GROUP_ID")

# Validation
def validate_config():
    """Validate that all required environment variables are set"""
    missing_vars = []
    
    if not BOT_TOKEN:
        missing_vars.append("BOT_TOKEN")
    if not PUBLIC_CHANNEL_USERNAME:
        missing_vars.append("PUBLIC_CHANNEL_USERNAME")
    if not PRIVATE_GROUP_ID:
        missing_vars.append("PRIVATE_GROUP_ID")
        
    if missing_vars:
        raise ValueError(f"Missing required environment variables: {', '.join(missing_vars)}")

# Message templates
MESSAGES = {
    "welcome": "Welcome! To get access to our private group, please follow these steps:",
    "not_subscribed": "❌ You are not subscribed. Please join our channel first:",
    "subscribed": "✅ Thank you for following me",
    "link_error": "⚠️ Sorry, I couldn't generate your invite link. Please try again later.",
    "general_error": "An error occurred. Please try again later."
}
