import os
import requests
import asyncio
import nest_asyncio
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import (
    Application,
    CommandHandler,
    CallbackQueryHandler,
    ContextTypes
)
from telegram.constants import ChatMemberStatus

from config import (
    BOT_TOKEN, 
    PUBLIC_CHANNEL_USERNAME, 
    PRIVATE_GROUP_ID, 
    MESSAGES, 
    validate_config
)
from logger import log_error, log_info
from keep_alive import keep_alive

# Apply nest_asyncio to allow nested event loops
nest_asyncio.apply()

try:
    # Start the keep-alive server before initializing the bot
    server_thread = keep_alive()
    log_info("Keep-alive server initialized")
except Exception as e:
    log_error(e, "Failed to start keep-alive server")
    raise  # Re-raise to ensure proper error handling

class SubscriptionBot:
    def __init__(self):
        self.app = None

    @staticmethod
    async def check_subscription(user_id: int) -> bool:
        """Check if a user is subscribed to the public channel"""
        url = f"https://api.telegram.org/bot{BOT_TOKEN}/getChatMember"
        params = {
            "chat_id": PUBLIC_CHANNEL_USERNAME,
            "user_id": user_id
        }

        try:
            response = requests.get(url, params=params)
            response.raise_for_status()
            data = response.json()

            if data.get("ok"):
                status = data["result"].get("status", "")
                return status in ["member", "administrator", "creator"]

            log_error(f"API Error checking subscription: {data}")
            return False

        except requests.RequestException as e:
            log_error(e, f"Failed to check subscription for user {user_id}")
            return False

    @staticmethod
    async def generate_unique_invite() -> str | None:
        """Generate a unique one-time invite link for the private group"""
        url = f"https://api.telegram.org/bot{BOT_TOKEN}/createChatInviteLink"
        payload = {
            "chat_id": PRIVATE_GROUP_ID,
            "member_limit": 1
        }

        try:
            response = requests.post(url, json=payload)
            response.raise_for_status()
            data = response.json()

            if data.get("ok"):
                return data["result"]["invite_link"]

            log_error(f"API Error generating invite link: {data}")
            return None

        except requests.RequestException as e:
            log_error(e, "Failed to generate invite link")
            return None

    @staticmethod
    def get_subscription_keyboard():
        """Get keyboard markup for subscription check"""
        return InlineKeyboardMarkup([
            [InlineKeyboardButton(
                "Join Channel", 
                url=f"https://t.me/{PUBLIC_CHANNEL_USERNAME.lstrip('@')}"
            )],
            [InlineKeyboardButton(
                "I have subscribed", 
                callback_data="check_subscription"
            )]
        ])

    @staticmethod
    def get_invite_keyboard(invite_link: str):
        """Get keyboard markup for invite link"""
        return InlineKeyboardMarkup([
            [InlineKeyboardButton("✨ Join Private Group 🙂", url=invite_link)]
        ])

    @classmethod
    async def start_command(cls, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle the /start command"""
        if not update.effective_message or not update.effective_user:
            return

        user = update.effective_user
        log_info(f"Start command received from user {user.username} (ID: {user.id})")

        try:
            if await cls.check_subscription(user.id):
                unique_link = await cls.generate_unique_invite()
                if unique_link:
                    await update.effective_message.reply_text(
                        MESSAGES["subscribed"],
                        reply_markup=cls.get_invite_keyboard(unique_link)
                    )
                else:
                    await update.effective_message.reply_text(MESSAGES["link_error"])
            else:
                await update.effective_message.reply_text(
                    MESSAGES["not_subscribed"],
                    reply_markup=cls.get_subscription_keyboard()
                )
        except Exception as e:
            log_error(e, f"Error in start command for user {user.id}")
            await update.effective_message.reply_text(MESSAGES["general_error"])

    @classmethod
    async def subscription_callback(cls, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle subscription verification callback"""
        if not update.callback_query or not update.callback_query.message:
            return

        query = update.callback_query
        if not query.from_user:
            return

        await query.answer()

        try:
            if await cls.check_subscription(query.from_user.id):
                unique_link = await cls.generate_unique_invite()
                if unique_link:
                    await query.message.edit_text(
                        MESSAGES["subscribed"],
                        reply_markup=cls.get_invite_keyboard(unique_link)
                    )
                else:
                    await query.message.edit_text(MESSAGES["link_error"])
            else:
                await query.message.edit_text(
                    MESSAGES["not_subscribed"],
                    reply_markup=cls.get_subscription_keyboard()
                )
        except Exception as e:
            log_error(e, f"Error in subscription callback for user {query.from_user.id}")
            await query.message.edit_text(MESSAGES["general_error"])

    async def setup(self):
        """Initialize the bot application"""
        try:
            # Validate configuration
            validate_config()

            # Build application
            self.app = Application.builder().token(BOT_TOKEN).build()

            # Add handlers
            self.app.add_handler(CommandHandler("start", self.start_command))
            self.app.add_handler(CallbackQueryHandler(
                self.subscription_callback, 
                pattern="^check_subscription$"
            ))

            log_info("🚀 Bot setup completed successfully")
            return True

        except Exception as e:
            log_error(e, "Error during bot setup")
            return False

def main():
    """Main entry point"""
    bot = SubscriptionBot()

    async def start_bot():
        if await bot.setup():
            log_info("Starting bot...")
            await bot.app.run_polling()

    try:
        # Run the bot
        asyncio.run(start_bot())
    except KeyboardInterrupt:
        log_info("Bot stopped by user")
    except Exception as e:
        log_error(e, "Fatal error in main")

if __name__ == "__main__":
    main()